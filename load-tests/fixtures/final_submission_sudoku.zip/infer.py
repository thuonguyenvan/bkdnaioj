from __future__ import annotations

import argparse
import csv
import io
import json
import zipfile
from pathlib import Path

from PIL import Image, ImageChops


def load_inputs(assets_dir: Path) -> tuple[list[str], dict[str, list[Image.Image]]]:
    images: dict[str, list[Image.Image]] = {}
    with zipfile.ZipFile(assets_dir / "inputs") as zf:
        metadata = json.loads(zf.read("metadata.json").decode("utf-8"))
        image_ids = metadata["image_ids"]
        for image_id in image_ids:
            parts = []
            for idx in range(1, 5):
                name = f"broken_sudoku_image/{image_id}/{image_id}_part_{idx}.png"
                with zf.open(name) as fh:
                    parts.append(Image.open(io.BytesIO(fh.read())).convert("RGB"))
            images[image_id] = parts
    return image_ids, images


def reconstruct_from_parts(parts: list[Image.Image]) -> Image.Image:
    # The fragments share the same 450x450 canvas with white background.
    # Darker-compositing keeps black grid/digits from every part without using ground truth.
    out = Image.new("RGB", (450, 450), (255, 255, 255))
    for part in parts:
        out = ImageChops.darker(out, part.resize((450, 450)))
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--submission-dir", required=True)
    parser.add_argument("--assets-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--context", required=True)
    args = parser.parse_args()

    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    recon_dir = output_dir / "reconstructed_images"
    recon_dir.mkdir(parents=True, exist_ok=True)

    image_ids, part_map = load_inputs(Path(args.assets_dir))
    for image_id in image_ids:
        reconstruct_from_parts(part_map[image_id]).save(recon_dir / f"{image_id}.png")

    with (output_dir / "output.csv").open("w", encoding="utf-8", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["image_id", "solution"])
        writer.writeheader()
        for image_id in image_ids:
            # Honest baseline: this sample reconstructs images only. It does not OCR or solve Sudoku.
            writer.writerow({"image_id": image_id, "solution": "0" * 81})


if __name__ == "__main__":
    main()
