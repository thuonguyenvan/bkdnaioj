import argparse
import os
import shutil
import zipfile

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--submission-dir", required=True)
    parser.add_argument("--assets-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--context", required=True)
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    # Poor contestant code: just extract clean images directly to the output directory
    # (no perturbation, fails to attack)
    inputs_zip = os.path.join(args.assets_dir, "inputs.zip")
    with zipfile.ZipFile(inputs_zip, 'r') as zf:
        zf.extractall(args.output_dir)

    print("Inference completed successfully.")

if __name__ == "__main__":
    main()
