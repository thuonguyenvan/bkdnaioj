import argparse
import json
import os
import struct
import zipfile

def read_bmp(path):
    with open(path, 'rb') as f:
        header = f.read(54)
        if len(header) < 54 or header[:2] != b'BM':
            raise ValueError(f"Not a valid BMP file: {path}")
        width, height = struct.unpack('<ii', header[18:26])
        if width != 28 or height != 28:
            raise ValueError(f"Image must be 28x28, got {width}x{height}")
        pixels = [0] * 784
        for y in reversed(range(height)):
            for x in range(width):
                bgr = f.read(3)
                if len(bgr) < 3:
                    raise ValueError(f"Unexpected EOF in BMP pixel data of {path}")
                val = sum(bgr) // 3
                pixels[y * width + x] = val
        return pixels

def save_bmp(path, img_data):
    width, height = 28, 28
    file_size = 54 + width * height * 3
    header = struct.pack(
        '<2sIHHI IiiHHIIiiII',
        b'BM',             # Signature
        file_size,         # File size
        0, 0,              # Reserved
        54,                # Data offset
        40,                # Header size
        width, height,     # Width and height
        1,                 # Planes
        24,                # Bits per pixel (24)
        0,                 # Compression (0 = none)
        width * height * 3, # Image size
        2835, 2835,        # Resolution
        0, 0               # Colors
    )
    with open(path, 'wb') as f:
        f.write(header)
        for y in reversed(range(height)):
            for x in range(width):
                val = int(img_data[y * width + x])
                f.write(bytes([val, val, val]))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--submission-dir", required=True)
    parser.add_argument("--assets-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--context", required=True)
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    # 1. Load target model weights
    weights_path = os.path.join(args.assets_dir, "model_weights.json")
    inputs_zip = os.path.join(args.assets_dir, "inputs.zip")
    if os.path.exists(weights_path):
        with open(weights_path, 'r', encoding='utf-8') as f:
            model = json.load(f)
    else:
        with zipfile.ZipFile(inputs_zip, 'r') as zf:
            if "model_weights.json" in zf.namelist():
                with zf.open("model_weights.json") as fh:
                    model = json.load(fh)
            else:
                raise FileNotFoundError("model_weights.json not found in assets_dir or inputs.zip")
    W = model["W"]
    b = model["b"]

    # 2. Extract inputs.zip containing clean images
    temp_extract = os.path.join(args.output_dir, "temp_inputs")
    os.makedirs(temp_extract, exist_ok=True)
    with zipfile.ZipFile(inputs_zip, 'r') as zf:
        zf.extractall(temp_extract)

    # 3. Perform attack on each BMP file and save to output-dir
    epsilon = 96
    for filename in os.listdir(temp_extract):
        if not filename.endswith(".bmp"):
            continue
        
        path = os.path.join(temp_extract, filename)
        pixels = read_bmp(path)

        # Get initial model prediction to target it
        x = [v / 255.0 for v in pixels]
        logits = [0.0, 0.0, 0.0]
        for c in range(3):
            val = b[c]
            for i in range(784):
                val += x[i] * W[i][c]
            logits[c] = val
        pred = logits.index(max(logits))

        # FGSM to decrease prediction of original class
        # pixel = pixel - epsilon * sign(W[:, pred])
        adv_pixels = [0] * 784
        for i in range(784):
            w_val = W[i][pred]
            grad_sign = 1 if w_val > 0 else (-1 if w_val < 0 else 0)
            val = int(pixels[i] - epsilon * grad_sign)
            if val < 0: val = 0
            if val > 255: val = 255
            adv_pixels[i] = val

        out_path = os.path.join(args.output_dir, filename)
        save_bmp(out_path, adv_pixels)

    print("Inference completed successfully.")

if __name__ == "__main__":
    main()
